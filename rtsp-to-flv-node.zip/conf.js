const requestConf = {
  url: 'localhost',
  port: 8100
}

module.exports = requestConf;